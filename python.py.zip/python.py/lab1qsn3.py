'''Qsn3 
Write a Python program to get a string made of the first 2 and the last 2 chars from a given a string. If the string length is less than 2, return instead of the empty string.   
Sample String : 'informationsecurity' 
Expected Result : 'inty' 
Sample String : 'hp' 
Expected Result : 'hphp' 
Sample String : ' w' 
Expected Result : Empty String   '''


def printstr(x):
  if len(x)<2:
    return ""
  else:
    return (x[0:3] + x[-3:])

y = raw_input("INPUT")
print(printstr(y))
